const state = {
	systemInfo: uni.getSystemInfoSync()
}

const actions = {

}

const mutations = {
	
}

export default {
	namespaced: true,
	state,
	mutations,
	actions
}