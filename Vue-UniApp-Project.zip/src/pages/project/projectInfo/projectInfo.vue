<template>
	<view class="page" :class="{'hide' : move1 }" @click="move2 && move()">
			<head-view ref="head"> </head-view>
			<Am-NavigationBar title=" " background="#FFFFFF">
				<image slot="content" src="@/static/indexImg/logo.png" style="width: 60rpx; height: 60rpx;margin-left: 40rpx;"
				 mode="aspectFit"></image>
				<image slot="content" src="@/static/indexImg/菜单icon.png" style="width: 28rpx; height: 24rpx;margin-left: 582rpx;"
				 mode="aspectFit" @click.stop="move"></image>
			</Am-NavigationBar>
		<view class="projectInfo_head">
			<text class="head">上海船舶研究设计院</text>
			<view class="body">
					<!-- <view class="" style="box-shadow: 0px 2px 4px 0px rgba(8,2,3,0.1); width: 670rpx; height: 1rpx;">	
					</view> -->
				<text class="left">http://www.sdari.com.cn/</text>
				<text class="right" >企业官网/响应式开发</text>
			</view>
		</view>
		<view class="projectInfo_body">
			<text>阿诗丹顿多多多多多多多多多多多多多多</text>
		</view>
		<view class="projectInfo_colors">
			<text class="title">colors</text>
			<view class="colorsList">
				<view class="colors_body">
					<view style="background-color: #1585cc;" class="colorsList_css">
					</view>
					<text class="colorsList_font">#1585cc</text>
				</view>
				<view class="colors_body">
					<view style="background-color: #15accc;" class="colorsList_css">
					</view>
					<text class="colorsList_font">#15accc</text>
				</view>
				<view class="colors_body">
					<view style="background-color: #155ecc;" class="colorsList_css">
					</view>
					<text class="colorsList_font">#155ecc</text>
				</view>
				<view class="colors_body">
					<view style="background-color: #4d4d4d;" class="colorsList_css">
					</view>
					<text class="colorsList_font">#4d4d4d</text>
				</view>
				<view class="colors_body">
					<view style="background-color: #999999;" class="colorsList_css">
					</view>
					<text class="colorsList_font">#999999</text>
				</view>
			</view>
		</view>
		
		<view class="projectInfo_bigFont">
				<text class=" bigFont">fonts</text>
				<view class=" bodyFont">
					<text class=" bigSize" >Aa</text>
					<view class="bigSize_right">
						<view class="text_kong">
						</view>
						<text style="font-size: 24rpx;">思源字体</text>
						<text style="font-size: 20rpx;">60px、48px、30px、16px</text>
					</view>
				</view>
		</view>
		
		<view class="projectInfo_imgList">
			<view class="title">
				<div class="rectangle">
				</div>
				<text class="title_home">首页</text>
			</view>
			<image src="../../../static/indexImg/组1_4.png" class="img" mode=""></image>
		</view>
		
		<view class="projectInfo_imgList">
			<view class="title">
				<div class="rectangle">
				</div>
				<text class="title_home">公司介绍</text>
			</view>
			<image src="../../../static/indexImg/组1_4.png" class="img" mode=""></image>
		</view>
		
		<view class="foot_module">
			<view class="foot_module_Navigation">
				<text class="tabbar">全部</text>
				<text class="tabbar">网站设计</text>
				<text class="tabbar">移动设计</text>
				<text class="tabbar">品牌形象</text>
				<text class="tabbar">电商设计</text>
			</view>
			<view class="foot_module_foot">
				<text class="foot_font">XSWLMADJD.PWE PELECE CALL WE</text>
				<text class="foot_font">沪ICP备09109183号-25</text>
			</view>
		</view>
	</view>

</template>

<script>
	import head from "@/components/common/title-head/head.vue"
	export default {
		data: () => ({
			index: null,
			move1: false,
			move2: false,
			ishide: true,
			num:'3'
		}),
		methods: {
			move() {
				this.$refs.head.tabShow(!this.move1,this.num)
				this.move1 = !this.move1
				this.move2 = !this.move2
				this.ishide = !this.ishide
			},
			isPrototypeOf() {
				this.isvisible = !this.isvisible
			}
		}
	}
</script>

<style lang="scss">
	.page{
		display: flex;
		width: 100vw;
		min-height: 100vh;
		&.hide {
			left: -70vw;
		}
		.swiper_banner {
			height: 460rpx;

			.banner_css {
				width: 750rpx;
				height: 460rpx;
			}
		}
		>.projectInfo_head{
			  padding: 50rpx 40rpx;
				box-sizing: border-box;
				display: flex;
				flex-direction: column;
			>.head{
				font-size: 34rpx;
				font-family: HYQiHei 60S, HYQiHei 60S-60S;
				font-weight: bold;
				text-align: left;
				color: #333333;
				// box-shadow: 0px 2px 4px 0px rgba(8,2,3,0.1); 
			}
			>.body{
				box-sizing: border-box;
				padding: 40rpx 0;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				>.left{
					font-size: 24rpx;
					font-family: HYQiHei 50S, HYQiHei 50S-50S;
					font-weight: 50S;
					text-align: left;
					color: #808080;
				}
				>.right{
					font-size: 24rpx;
					font-family: HYQiHei 50S, HYQiHei 50S-50S;
					font-weight: 50S;
					text-align: left;
					color: #e11612;
				}
			}
		}
		>.projectInfo_body{
			padding: 50rpx 40rpx;
			box-sizing: border-box;
			font-size: 26rpx;
			font-family: HYQiHei 50S, HYQiHei 50S-50S;
			font-weight: 50S;
			text-align: justifyLeft;
			color: #333333;
		}
		>.projectInfo_colors{
			padding: 40rpx 40rpx;
			box-sizing: border-box;
			>.title{
				font-size: 30rpx;
				font-family: Verdana Regular, Verdana Regular-Regular;
				font-weight: bold;
				font-style: italic;
				text-align: justifyLeft;
				color: #808080; 
			}
			>.colorsList{
				margin: 40rpx 0 0 0;
				display: flex;
				flex-direction: row;
			
				>.colors_body{
					display: flex;
					flex-direction: column;
					flex: 1;
					margin: 0 30rpx 0 30rpx;
					
					&:first-child{
					margin: 0 30rpx 0 0;
					}
					&:last-child{
						margin: 0 0rpx 0 30rpx;
					}
					>.colorsList_css{
						width: 80rpx;
						height: 80rpx;
						border-radius: 40rpx;
					}
					>.colorsList_font{
						margin: 10rpx 0;
						font-size: 20rpx;
						font-family: Arial Regular, Arial Regular-Regular;
						font-weight: 400;
						text-align: justifyLeft;
						color: #808080;
					}
				}		
			}
		}
		>.projectInfo_bigFont{
			padding: 30rpx 40rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			>.bigFont{
				font-size: 30rpx;
				font-family: Verdana Regular, Verdana Regular-Regular;
				font-weight: bold;
				font-style: italic;
				text-align: justifyLeft;
				color: #808080;
			}
			>.bodyFont{
				margin: 40rpx 0;
				display: flex;
				flex-direction: row;
				>.bigSize{
					font-size: 141rpx;
					font-family: Verdana Bold, Verdana Bold-Bold;
					font-weight: 700;
					font-style: italic;
					text-align: justifyLeft;
					color: #333333;
				}
				>.bigSize_right{
					display: flex;
					flex-direction: column;
					padding: 10rpx 20rpx;
					>.text_kong{
						display: block;
						height: 40rpx;
						width: 80rpx;	
						margin: 20rpx auto;
					}
				}
			}
		}
		>.projectInfo_imgList{
			box-sizing: border-box;
			padding: 30rpx 40rpx;
			>.title{
				margin: 20rpx 0;
				display: flex;
				flex-direction: row;
				align-items: center;
				>.rectangle{		
					width: 16rpx; 
					height: 16rpx;
					background-color: red;
					margin: 0 10rpx 0 0;
					transform:rotate(45deg);
					-ms-transform:rotate(45deg); 	/* IE 9 */
					-moz-transform:rotate(45deg); 	/* Firefox */
					-webkit-transform:rotate(45deg); /* Safari 和 Chrome */
					-o-transform:rotate(45deg);
				}
				>.title_home{
					font-size: 24rpx;
					font-family: HYQiHei 50S, HYQiHei 50S-50S;
					font-weight: 50S;
					text-align: justifyLeft;
					color: #e11612;
				}
			}
			>.img{
				width: 670rpx;
				height: 380rpx;
			}
			&:nth-child(n-1){
				padding: 0 40rpx 20rpx 40rpx;
			}
		
		}
		>.foot_module {
			box-sizing: border-box;
			background-color: #333333;
			color: #ffffff;
			display: flex;
			flex-direction: column;
			margin: 40rpx 0 0 0;

			>.foot_module_Navigation {
				margin: 40rpx 0;
				text-align: center;
				display: flex;
				flex-direction: row;

				>.tabbar {
					flex: 1;
					font-size: 22rpx;
					letter-spacing: 1rpx;

					&:nth-child(n+2) {
						border-left: 0.5rpx solid rgba(255, 255, 255, 0.3);
						flex: 1;
						font-size: 22rpx;
						letter-spacing: 1rpx;
					}
				}
			}

			>.foot_module_foot {
				display: flex;
				flex-direction: column;
				align-items: center;
				margin: 24rpx auto;

				>.foot_font {
					margin: 13rpx auto;
					font-size: 18rpx;
					font-family: HYQiHei 50S, HYQiHei 50S-50S;
					font-weight: 50S;
					text-align: left;
					line-height: 20rpx;
				}
			}
		}
	}
</style>
